import os
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_openai import OpenAI
from langchain.chains import RetrievalQA

# Load environment variable for safety (optional but best practice)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "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")  # Replace with your key if needed

# Paths
DATA_PATH = "app/rag/faiss_drinkware_index"

# Load embedding model
embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# Load FAISS vector store
vectordb = FAISS.load_local(
    folder_path=DATA_PATH,
    embeddings=embedding_model,
    index_name="index",
    allow_dangerous_deserialization=True  # required to load FAISS safely
)

# Load RAG chain
rag_chain = RetrievalQA.from_chain_type(
    llm=OpenAI(temperature=0, openai_api_key=OPENAI_API_KEY),
    retriever=vectordb.as_retriever()
)
